<!DOCTYPE html>
<html>
<head>
    <title>Idea Tournament</title>
</head>
<body>
    <h1>Congrats!! Winner</h1>
    <p>Congratulation! You idea has been selected.</p>
   
    <p>Thank you</p>
</body>
</html>