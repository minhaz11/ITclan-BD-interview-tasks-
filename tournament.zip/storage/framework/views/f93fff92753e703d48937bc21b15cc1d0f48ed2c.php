<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Idea Tournament</title>

        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap" rel="stylesheet">
    </head>
    <body>
        <div class="container" id="app">
            <?php if(!session('tournament')): ?>
                <div class="row justify-content-center mt-5">
                    <div class="col-md-8">
                        <h2 class="my-4">IDEA TOURNAMENT</h2>
                        <form action="<?php echo e(route('idea.store')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                                <div class="form-group mb-2">
                                    <label for="name">Name</label>
                                    <input id="name" class="form-control" type="text" name="name" required value="<?php echo e(old('name')); ?>">
                                </div>
                                <div class="form-group mb-2">
                                    <label for="email">Email</label>
                                    <input id="email" class="form-control" type="text" name="email" required value="<?php echo e(old('email')); ?>">
                                </div>
                                <div class="form-group mb-2">
                                    <label for="idea">Idea</label>
                                    <input id="idea" class="form-control" type="text" name="idea" required value="<?php echo e(old('idea')); ?>">
                                </div>

                                <div class="form-group text-end">
                                    <button class="btn btn-primary" type="submit">Submit</button>
                                </div>
                        </form>
                    </div>
                </div>
            <?php endif; ?>
            <hr>

            <div class="row justify-content-center mt-5 mb-5" id="winner-box">
                <div class="col-md-10 text-center">
                    <?php if(!session('tournament') && $perticipants->count() < 8): ?>
                       <h6><span class="text-primary"><?php echo e(8 - $perticipants->count()); ?></span> Perticipants remaining for start the tournaments</h6>
                    <?php else: ?>
                      <div class="d-flex justify-content-between mb-3">
                        <?php if( $perticipants->count() == 1): ?> 
                          <h6>Next tournament is starting soon</h6>
                        <?php else: ?>
                        <h6>Current perticipants of the tournament</h6>
                        <?php endif; ?>
                       
                         <h5 id="timer">Time : 0m 0s</h5>
                      </div>

                      <table class="table table-light table-striped" >
                          <thead class="thead-light">
                              <tr>
                                  <th>Name</th>
                                  <th>Email</th>
                                  <th>Idea</th>
                                  <th>Wining Status</th>
                              </tr>
                          </thead>
                          <tbody>
                              <?php $__currentLoopData = $perticipants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <tr>
                                  <td><?php echo e($user->name); ?></td>
                                  <td><?php echo e($user->email); ?></td>
                                  <td><?php echo e($user->idea); ?></td>
                                  <td>
                                      <?php if( $perticipants->count() == 1): ?>
                                          <span class="badge bg-success">Winner</span>
                                       <?php else: ?>
                                       <span class="badge bg-warning">Pending</span>
                                      <?php endif; ?>
                                      
                                  </td>
                              </tr>  
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </tbody>
                      </table>
                    <?php endif; ?>
                    
                </div>
            </div>
        </div>
    
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" ></script>
        <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
        <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>

        <?php echo $__env->make('alerts.error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('alerts.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('alerts.success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <?php if(session('tournament') && $perticipants->count() != 1): ?>
            <script>
                var duration = 1
                var countDownDate = new Date();
                countDownDate.setMinutes(countDownDate.getMinutes() + parseInt(duration));
                var x = setInterval(function () {  
                    var now = new Date().getTime();  
                    var distance = countDownDate - now; 
                    var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
                    var seconds = Math.floor((distance % (1000 * 60)) / 1000); 
                    document.getElementById("timer").innerHTML = 'Timer : '+ minutes + "m " + seconds + "s "; 
    
                    if (distance < 0) {
                        document.getElementById("timer").innerHTML = '0m 0s'
                        clearInterval(x);
                        var data = {
                            _token:'<?php echo e(csrf_token()); ?>'
                        }
                        $.post('<?php echo e(route('elimination')); ?>',data).done(function (res) { 
                            location.reload()
                        })
                    }
                }, 1000);
            </script>
        <?php endif; ?>
    </body>
</html>
<?php /**PATH D:\xampp\htdocs\tournament\resources\views/welcome.blade.php ENDPATH**/ ?>